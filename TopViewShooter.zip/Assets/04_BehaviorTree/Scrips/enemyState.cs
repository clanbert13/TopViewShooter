using System;
using Unity.Behavior;

[BlackboardEnum]
public enum enemyState
{
    IDLE,
	ATTACK,
	CHASE
}
